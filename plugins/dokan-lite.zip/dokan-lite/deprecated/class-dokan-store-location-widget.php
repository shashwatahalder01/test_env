<?php

class Dokan_Store_Location {}
