<?php

use WeDevs\Dokan\Abstracts\DokanRESTController;

class Dokan_REST_Controller extends DokanRESTController {}
